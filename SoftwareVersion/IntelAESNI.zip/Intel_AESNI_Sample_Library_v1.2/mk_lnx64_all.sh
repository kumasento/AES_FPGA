#!/bin/sh

./mk_lnx.sh 64
